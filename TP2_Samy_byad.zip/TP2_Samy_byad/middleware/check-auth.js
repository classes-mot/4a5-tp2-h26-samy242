import jwt from 'jsonwebtoken';

const checkAuth = (req, res, next) => {
  if (req.method === 'OPTIONS') {
    return next();
  }

  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      const error = new Error('Authentification échouée.');
      error.code = 401;
      return next(error);
    }

    const token = authHeader.split(' ')[1];
    const decodedToken = jwt.verify(token, 'secret123');

    req.userData = {
      userId: decodedToken.userId,
      email: decodedToken.email
    };

    next();
  } catch (err) {
    err.code = 401;
    next(err);
  }
};

export default checkAuth;