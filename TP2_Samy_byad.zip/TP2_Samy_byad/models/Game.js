import mongoose from 'mongoose';

const gameSchema = new mongoose.Schema({
  titre: {
    type: String,
    required: true,
    trim: true
  },
  genre: {
    type: String,
    required: true,
    trim: true
  },
  prix: {
    type: Number,
    required: true,
    min: 0
  },
  nbJoueur: {
    type: Number,
    required: true,
    min: 2
  },
  createur: {
    type: mongoose.Types.ObjectId,
    required: true,
    ref: 'User'
  }

});

export default mongoose.model('Game', gameSchema);