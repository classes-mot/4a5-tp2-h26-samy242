import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

export const register = async (req, res, next) => {
  const { nom, email, motDePasse } = req.body;

  if (!nom || !email || !motDePasse) {
    const error = new Error('Tous les champs sont obligatoires.');
    error.code = 422;
    return next(error);
  }

  try {
    const userExistant = await User.findOne({ email });

    if (userExistant) {
      const error = new Error('Cet utilisateur existe déjà.');
      error.code = 422;
      return next(error);
    }

    const motDePasseHache = await bcrypt.hash(motDePasse, 12);

    const newUser = new User({
      nom,
      email,
      motDePasse: motDePasseHache
    });

    await newUser.save();

    res.status(201).json({
      message: 'Utilisateur créé avec succès.',
      userId: newUser._id
    });
  } catch (err) {
    next(err);
  }
};

export const login = async (req, res, next) => {
  const { email, motDePasse } = req.body;

  if (!email || !motDePasse) {
    const error = new Error('Email et mot de passe obligatoires.');
    error.code = 422;
    return next(error);
  }

  try {
    const user = await User.findOne({ email });

    if (!user) {
      const error = new Error('Utilisateur introuvable.');
      error.code = 401;
      return next(error);
    }

    const isValidPassword = await bcrypt.compare(motDePasse, user.motDePasse);

    if (!isValidPassword) {
      const error = new Error('Mot de passe invalide.');
      error.code = 401;
      return next(error);
    }

    const token = jwt.sign(
      {
        userId: user._id,
        email: user.email
      },
      'secret123',
      { expiresIn: '1h' }
    );

    res.status(200).json({
      message: 'Connexion réussie.',
      userId: user._id,
      email: user.email,
      token: token
    });
  } catch (err) {
    next(err);
  }
};