import Game from '../models/Game.js';

export const getGames = async (req, res, next) => {
  try {
    const games = await Game.find()
    res.status(200).json({ games });
  } catch (err) {
    next(err);
  }
};

export const getGameById = async (req, res, next) => {
  const gameId = req.params.gid;

  try {
    const game = await Game.findById(gameId)

    if (!game) {
      const error = new Error('Jeu introuvable.');
      error.code = 404;
      return next(error);
    }

    res.status(200).json({ game });
  } catch (err) {
    next(err);
  }
};

export const createGame = async (req, res, next) => {
  const { titre, genre, prix,nbJoueur } = req.body;

  if (!titre || !genre || prix === undefined) {
    const error = new Error('Tous les champs sont obligatoires.');
    error.code = 422;
    return next(error);
  }

  const createdGame = new Game({
    titre,
    genre,
    prix,
    nbJoueur,
    createur: req.userData.userId
  });

  try {
    await createdGame.save();

    res.status(201).json({
      message: 'Jeu ajouté avec succès.',
      game: createdGame
    });
  } catch (err) {
    next(err);
  }
};

export const updateGame = async (req, res, next) => {
  const { titre, genre, prix, nbJoueur } = req.body;
  const gameId = req.params.gid;

  try {
    const game = await Game.findById(gameId);

    if (!game) {
      const error = new Error('Jeu introuvable.');
      error.code = 404;
      return next(error);
    }

    if (game.createur.toString() !== req.userData.userId) {
      const error = new Error("Vous n'êtes pas autorisé à modifier ce jeu.");
      error.code = 403;
      return next(error);
    }

    game.titre = titre ?? game.titre;
    game.genre = genre ?? game.genre;
    game.prix = prix ?? game.prix;
    game.nbJoueur = nbJoueur ?? game.nbJoueur;

    await game.save();

    res.status(200).json({
      message: 'Jeu modifié avec succès.',
      game
    });
  } catch (err) {
    next(err);
  }
};

export const deleteGame = async (req, res, next) => {
  const gameId = req.params.gid;

  try {
    const game = await Game.findById(gameId);

    if (!game) {
      const error = new Error('Jeu introuvable.');
      error.code = 404;
      return next(error);
    }

    if (game.createur.toString() !== req.userData.userId) {
      const error = new Error("Vous n'êtes pas autorisé à supprimer ce jeu.");
      error.code = 403;
      return next(error);
    }

    await Game.findByIdAndDelete(gameId);

    res.status(200).json({
      message: 'Jeu supprimé avec succès.'
    });
  } catch (err) {
    next(err);
  }
};