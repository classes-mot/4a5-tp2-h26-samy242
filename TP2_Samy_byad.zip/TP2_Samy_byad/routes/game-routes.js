import express from 'express';
import {
  getGames,
  getGameById,
  createGame,
  updateGame,
  deleteGame
} from '../controllers/game-controller.js';
import checkAuth from '../middleware/check-auth.js';
const router = express.Router();

router.get('/', getGames);
router.get('/:gid', getGameById);

router.use(checkAuth);

router.post('/', createGame);
router.patch('/:gid', updateGame);
router.delete('/:gid', deleteGame);

export default router;